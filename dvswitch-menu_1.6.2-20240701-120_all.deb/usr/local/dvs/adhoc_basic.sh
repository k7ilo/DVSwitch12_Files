#!/bin/bash

#===================================
SCRIPT_VERSION="Menu Script v.1.60"
SCRIPT_AUTHOR="HL5KY"
SCRIPT_DATE="10/15/2020"
#===================================

source /var/lib/dvswitch/dvs/var.txt


#------ do_restart_service() -----------------------------------------------------
do_restart_service() {

clear

TERM=ansi whiptail --title "$T029" --infobox "$T006" 8 60

${DVS}88_restart.sh

whiptail --msgbox "\

$sp27 $T003

$sp23 $T004

" 10 70 1
}

#------ do_change_to_adv() ----------------------------------------------------------
do_change_to_adv() {
# if there is not dvsm.basic, Basic macro is being used

clear

TERM=ansi whiptail --title "$T029" --infobox "$T006" 8 60

if [ ! -e ${AB}dvsm.basic ]; then
	sudo mv ${AB}dvsm.macro ${AB}dvsm.basic
	sudo \cp -f ${adv}dvsm.* ${AB}
	sudo chmod +x ${AB}dvsm.sh

	if [ -d ${adv}${LN} ]; then
		sudo \cp -f ${adv}${LN}/*.* ${AB}
	else
		sudo \cp -f ${adv}EN/*.* ${AB}
	fi
#                crontab -l | perl -nle 's/^#\s*([0-9*])/$1/;print' | crontab
#                sudo service cron restart
#                ${DVS}88_restart.sh

# config adv_dmr.txt file with available DMR servers
	${DVS}adnl_dmr.sh advdmr_return > /dev/null

for file in ${AB}Analog_Bridge.ini
        do
	sudo sed -i -e "/^usrpAudio/ c usrpAudio = AUDIO_USE_GAIN              ; Digital -> Analog (AUDIO_UNITY, AUDIO_USE_GAIN, AUDIO_USE_AGC)" "$file"
        sudo sed -i -e "/^usrpGain/ c usrpGain = ${usrpGain}                         ; Gain factor when usrpAudio = AUDIO_USE_GAIN (0.0 to 5.0) (1.0 = AUDIO_UNITY)" "$file"
        sudo sed -i -e "/^tlvAudio/ c tlvAudio = AUDIO_USE_GAIN               ; Analog -> Digital (AUDIO_UNITY, AUDIO_USE_GAIN, AUDIO_BPF)" "$file"
        sudo sed -i -e "/^tlvGain/ c tlvGain = ${txgain_dmr}                          ; Gain factor when tlvAudio = AUDIO_USE_GAIN (0.0 to 5.0) (1.0 = AUDIO_UNITY)" "$file"
	done
fi

${DVS}88_restart.sh

whiptail --msgbox "\

$sp03 $T263

$sp03 $T264
" 10 70 1

${DVS}adhoc_check.sh; exit 0
}

#------ MAIN---------------------------------------------------------------------------------------

#  BASIC Macro Configuration
if (whiptail --title " $T260 " --yesno "\
$T261

$T262

$T005
" 12 70); then do_change_to_adv
fi

if [ $? != 0 ]; then ${DVS}}adv_config_menu.sh; exit 0
fi


#OPTION=$(whiptail --title " Adhoc Menu & Macro " --menu "\
#                <BASIC>\n
#. SAVE  : Ctrl-X >> Y >> Enter           \
# . CANCEL: Ctrl-X >> N                   \
#-----------------------------------------\
#. To apply editing, <Restart DVSwitch>   \
#" 28 45 14 \
#1 "$T007 <BASIC> dvsm.macro" \
#2 "$T007 00.txt" \
#3 "$T007 01.txt" \
#4 "$T007 02.txt" \
#5 "$T007 03.txt" \
#6 "$T007 04.txt" \
#7 "$T007 05.txt" \
#8 "$T007 06.txt" \
#9 "$T007 07.txt" \
#10 "$T007 08.txt" \
#11 "$T007 09.txt" \
#12 "$T275" \
#13 "Change to <ADVANCED> dvsm.macro" \
#14 "Back" 3>&1 1>&2 2>&3)

#if [ $? != 0 ]; then ${DVS}adv_config.sh
#fi

#case $OPTION in
#1)
#sudo nano ${AB}dvsm.macro; ${DVS}adhoc_basic.sh ;;
#2)
#sudo nano ${AB}0.txt; ${DVS}adhoc_basic.sh ;;
#3)
#sudo nano ${AB}1.txt; ${DVS}adhoc_basic.sh ;;
#4)
#5udo nano ${AB}2.txt; ${DVS}adhoc_basic.sh ;;
#6)
#sudo nano ${AB}3.txt; ${DVS}adhoc_basic.sh ;;
#7)
#sudo nano ${AB}4.txt; ${DVS}adhoc_basic.sh ;;
#8)
#sudo nano ${AB}5.txt; ${DVS}adhoc_basic.sh ;;
#9)
#sudo nano ${AB}6.txt; ${DVS}adhoc_basic.sh ;;
#10)
#sudo nano ${AB}7.txt; ${DVS}adhoc_basic.sh ;;
#10)
#sudo nano ${AB}8.txt; ${DVS}adhoc_basic.sh ;;
#11)
#sudo nano ${AB}9.txt; ${DVS}adhoc_basic.sh ;;
#12)
#do_restart_service; ${DVS}adhoc_basic.sh ;;
#13)
#do_change_to_adv ;;
#14)
#${DVS}adv_config.sh; exit 0 ;;
#esac

#------ END of MAIN ---------------------------------------------------------------------------------------

clear

${DVS}adv_config_menu.sh

exit 0

#!/bin/bash

#===================================
SCRIPT_VERSION="Menu Script v.1.60"
SCRIPT_AUTHOR="HL5KY"
SCRIPT_DATE="10/15/2020"
#===================================


for service in mmdvm_bridge analog_bridge;
do
    sudo systemctl restart ${service}
done

#sudo systemctl restart quantar_bridge
#sudo systemctl restart mmdvm_bridge
#sudo systemctl restart analog_bridge
#sudo systemctl restart p25gateway
#sudo systemctl restart nxdngateway
#sudo systemctl restart ysfgateway
#sudo systemctl restart ircddbgatewayd.service

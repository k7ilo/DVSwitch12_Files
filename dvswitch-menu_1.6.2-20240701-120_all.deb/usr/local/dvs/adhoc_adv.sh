#!/bin/bash

#===================================
SCRIPT_VERSION="Menu Script v.1.60"
SCRIPT_AUTHOR="HL5KY"
SCRIPT_DATE="10/15/2020"
#===================================

source /var/lib/dvswitch/dvs/var.txt

#------ do_restart_service() -----------------------------------------------------
do_restart_service() {

clear

TERM=ansi whiptail --title "$T029" --infobox "$T006" 8 60

${DVS}88_restart.sh

whiptail --msgbox "\

$sp27 $T003

$sp23 $T004

" 10 70 1
}

#------ do_change_to_basic() ----------------------------------------------------------
do_change_to_basic() {

TERM=ansi whiptail --title "$T029" --infobox "$T006" 8 60

# if there is dvsm.basic, Advanced macro is being used.
if [ -e ${AB}dvsm.basic ]; then
	sudo rm ${AB}adv_*.txt
#        sudo rm ${AB}extra_*.txt
        sudo rm ${AB}dvsm.macro
        sudo rm ${AB}dvsm.sh
        sudo mv ${AB}dvsm.basic ${AB}dvsm.macro
#                sudo service cron stop
#                crontab -l | perl -nle 's/^([^#])/# $1/;print' | crontab
#                ${DVS}88_restart.sh
for file in ${AB}Analog_Bridge.ini
        do
        sudo sed -i -e "/^usrpAudio/ c usrpAudio = AUDIO_UNITY                  ; Digital -> Analog (AUDIO_UNITY, AUDIO_USE_GAIN, AUDIO_USE_AGC)" "$file"
        sudo sed -i -e "/^usrpGain/ c usrpGain = ${usrpGain_default}                         ; Gain factor when usrpAudio = AUDIO_USE_GAIN (0.0 to 5.0) (1.0 = AUDIO_UNITY)" "$file"
        sudo sed -i -e "/^tlvAudio/ c tlvAudio = AUDIO_UNITY                  ; Analog -> Digital (AUDIO_UNITY, AUDIO_USE_GAIN, AUDIO_BPF)" "$file"
        sudo sed -i -e "/^tlvGain/ c tlvGain = ${txgain_dmr_default}                          ; Gain factor when tlvAudio = AUDIO_USE_GAIN (0.0 to 5.0) (1.0 = AUDIO_UNITY)" "$file"
	done
fi

whiptail --msgbox "\

$T278

" 10 70 1

${DVS}adv_config_menu.sh; exit 0
}

#------ MAIN---------------------------------------------------------------------------------------
clear

OPTION=$(whiptail --title " $T203 " --menu "\
$sp16 $T270\n
$sp06 $T001 : Ctrl-X >> Y >> Enter
$sp06 $T002 : Ctrl-X >> N
----------------------------------------------
$sp06 $T273
" 24 50 10 \
1 "$T007 $T274 dvsm.macro" \
2 "$T007 adv_main.txt" \
3 "$T007 extra_1.txt" \
4 "$T007 extra_2.txt" \
5 "$T007 extra_3.txt" \
6 "$T007 extra_4.txt" \
7 "$T007 extra_5.txt" \
8 "$T275" \
9 "$T276" \
10 "$T277" 3>&1 1>&2 2>&3)

if [ $? != 0 ]; then ${DVS}adv_config_menu.sh; fi

case $OPTION in
1)
sudo nano ${AB}dvsm.macro; ${DVS}adhoc_adv.sh ;;
2)
sudo nano ${AB}adv_main.txt; ${DVS}adhoc_adv.sh ;;
3)
sudo nano ${AB}extra_1.txt; ${DVS}adhoc_adv.sh ;;
4)
sudo nano ${AB}extra_2.txt; ${DVS}adhoc_adv.sh ;;
5)
sudo nano ${AB}extra_3.txt; ${DVS}adhoc_adv.sh ;;
6)
sudo nano ${AB}extra_4.txt; ${DVS}adhoc_adv.sh ;;
7)
sudo nano ${AB}extra_5.txt; ${DVS}adhoc_adv.sh ;;
8)
do_restart_service; ${DVS}adhoc_adv.sh ;;
9)
do_change_to_basic ;;
10)
${DVS}adv_config_menu.sh; exit 0 ;;
esac

#------ END of MAIN ---------------------------------------------------------------------------------------

clear

exit 0

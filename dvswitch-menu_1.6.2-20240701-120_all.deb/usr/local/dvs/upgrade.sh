#!/bin/bash

#===================================
SCRIPT_VERSION="Menu Script v.1.61"
SCRIPT_AUTHOR="HL5KY"
SCRIPT_DATE="11/23/2020"
#===================================

source /var/lib/dvswitch/dvs/var.txt


########################################################################################
function return() {

source /var/lib/dvswitch/dvs/var.txt > /dev/null 2>&1

file=/var/lib/dvswitch/dvs/var.txt
for var in ${new_var}; do
        if [[ -z `sudo grep "^$var" $file` ]]; then
                echo "$var=" | sudo tee -a $file > /dev/null 2>&1
                val=${new_val[$n]}
                update_var $var $val
        fi
        n=$(($n+1))
done





exit 0
}
########################################################################################



############################################
#  MAIN SCRIPT
############################################

if [ "$1" = "return" ]; then
return
fi


#!/bin/bash

#===================================
SCRIPT_VERSION="Menu Script v.1.60"
SCRIPT_AUTHOR="HL5KY"
SCRIPT_DATE="10/15/2020"
#===================================

source /var/lib/dvswitch/dvs/var.txt


OPTION=$(whiptail --title " $T211 " --menu "\
\n
$sp05 $T001: Ctrl-X >> Y >> Enter
$sp05 $T002: Ctrl-X >> N
" 21 43 10 \
1 "$T007 Analog_Bridge.ini" \
2 "$T007 MMDVM_Bridge.ini" \
3 "$T007 NXDNGateway.ini" \
4 "$T007 P25Gateway.ini" \
5 "$T007 YSFGateway.ini" \
6 "$T007 Quantar_Bridge.ini" \
7 "$T007 ircddbgateway" \
8 "$T007 DVSwitch.ini" \
9 "Back"  3>&1 1>&2 2>&3)

if [ $? != 0 ]; then ${DVS}tools_menu.sh; exit 0
fi

case $OPTION in
1)
sudo nano ${AB}Analog_Bridge.ini; ${DVS}config_ini.sh ;;
2)
sudo nano ${MB}MMDVM_Bridge.ini; ${DVS}config_ini.sh ;;
3)
sudo nano /opt/NXDNGateway/NXDNGateway.ini; ${DVS}config_ini.sh ;;
4)
sudo nano /opt/P25Gateway/P25Gateway.ini; ${DVS}config_ini.sh ;;
5)
sudo nano /opt/YSFGateway/YSFGateway.ini; ${DVS}config_ini.sh ;;
6)
sudo nano /opt/Quantar_Bridge/Quantar_Bridge.ini; ${DVS}config_ini.sh ;;
7)
sudo nano /etc/ircddbgateway; ${DVS}config_ini.sh ;;
8)
sudo nano ${MB}DVSwitch.ini; ${DVS}config_ini.sh ;;
9)
sudo ${DVS}tools_menu.sh; exit 0

esac

clear

exit 0

#!/bin/bash

#===================================
SCRIPT_VERSION="Menu Script v.1.60"
SCRIPT_AUTHOR="HL5KY"
SCRIPT_DATE="10/15/2020"
#===================================

source /var/lib/dvswitch/dvs/var.txt


OPTION=$(whiptail --title " $T200 " --menu "\
\n
" 13 110 5 \
"21 $T209     " "$T210" \
"22 $T201     " "$T202" \
"23 $T203     " "$T204" \
"24 $T205     " "$T206" \
"25 $T207     " "$T208" 3>&1 1>&2 2>&3)

if [ $? != 0 ]; then
	sudo ${DVS}dvs; exit 0
fi

case $OPTION in
21\ *)sudo ${DVS}config_other_stz.sh ;;
22\ *)sudo ${DVS}tgdb.sh ;;
23\ *)sudo ${DVS}adhoc_check.sh ;;
24\ *)sudo ${DVS}adnl_dmr.sh ;;
25\ *)sudo ${DVS}dvs; exit 0 ;;
esac

#clear

exit 0


#!/bin/bash

#===================================
SCRIPT_VERSION="Menu Script v.1.60"
SCRIPT_AUTHOR="HL5KY"
SCRIPT_DATE="10/15/2020"
#===================================

source /var/lib/dvswitch/dvs/var.txt

if [ -e ${AB}dvsm.basic ]; then
${DVS}adhoc_adv.sh

elif [ ! -e ${AB}dvsm.basic ]; then
${DVS}adhoc_basic.sh

fi

exit 0




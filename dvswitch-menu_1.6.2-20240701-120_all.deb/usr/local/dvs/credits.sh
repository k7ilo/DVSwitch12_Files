#!/bin/bash

#===================================
SCRIPT_VERSION="Menu Script v.1.60"
SCRIPT_AUTHOR="HL5KY"
SCRIPT_DATE="10/15/2020"
#===================================

source /var/lib/dvswitch/dvs/var.txt


writer="${T034#*:}"

if [ ${#writer} -gt 4 ] && [ ${#writer} -lt 10 ]; then

whiptail --msgbox "\

$sp12 $T030

$sp12 $T031

$sp12 $T032

$sp12 $T034

$sp12 $T035

" 17 70 1
sudo ${DVS}dvs; exit 0


else

whiptail --msgbox "\

$sp12 $T030

$sp12 $T031

$sp12 $T032

$sp12 $T035

" 15 70 1
sudo ${DVS}dvs; exit 0

fi

#------------------------------------------------------------------------------------------------------------------------

clear

sudo ${DVS}dvs; exit 0

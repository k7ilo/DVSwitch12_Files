#!/bin/bash

#===================================
SCRIPT_VERSION="Menu Script v.1.61"
SCRIPT_AUTHOR="HL5KY"
SCRIPT_DATE="11/23/2020"
#===================================

source /var/lib/dvswitch/dvs/var.txt


#-------------------------------------------------------------------------
do_restart() {

clear

TERM=ansi whiptail --title "$T029" --infobox "$T006" 8 60

# variable ${services} is in func.txt
sudo systemctl restart $services > /dev/null 2>&1

clear

whiptail --msgbox "\

$sp12 $T194

$sp12 $T004

" 11 70 1

sudo ${DVS}dvs; exit 0
}

#-------------------------------------------------------------------------
do_chk_ini_changed() {

clear

if [[ -z `sudo grep ${dmr_id} ${AB}Analog_Bridge.ini` ]] || \
[[ -z `sudo grep ${call_sign} ${MB}MMDVM_Bridge.ini` ]] || \
[[ -z `sudo grep ${call_sign} /opt/NXDNGateway/NXDNGateway.ini` ]] || \
[[ -z `sudo grep ${call_sign} /opt/P25Gateway/P25Gateway.ini` ]] || \
[[ -z `sudo grep ${call_sign} /opt/YSFGateway/YSFGateway.ini` ]] || \
[[ -z `sudo grep ${call_sign} /etc/ircddbgateway` ]];
then
whiptail --msgbox "\

$sp12 $T392

$sp12 $T182

" 11 70 1



TERM=ansi whiptail --title "$T029" --infobox "$T006" 8 60

sudo ${DVS}init_config.sh return > /dev/null



whiptail --msgbox "\
$sp11 $T190

$sp11 $T194

$sp11 $T004

" 11 70 1
clear; ${DVS}dvs; exit 0


else
whiptail --msgbox "\

$sp12 $T392

$sp12 $T393

" 11 70 1

do_restart
fi
}

#-------------------------------------------------------------------------
do_upgrade() {

sudo \mv -f ${DATA}var.txt ${DATA}var.old > /dev/null 2>&1

#sudo apt-get update
sudo apt-get upgrade -y

sudo \mv -f /var/lib/dvswitch/dvs/var.old /var/lib/dvswitch/dvs/var.txt > /dev/null 2>&1
source /var/lib/dvswitch/dvs/var.txt > /dev/null 2>&1


# After upgrading, if [there is dvsm.basic] -> meaning setting is Advanced Macro Configuration
if [ -e ${AB}dvsm.basic ]; then
#    if there is not character "Advanced" in dvsm.macro -> updated & upgraded and dvsm.macro is brand new
        if [[ -z `grep "Advanced" ${AB}dvsm.macro` ]]; then
                sudo \cp -f ${adv}dvsm.macro ${AB}dvsm.macro
        fi
fi


${DVS}upgrade.sh return > /dev/null


language=`echo ${language} | tr '[A-Z]' '[a-z]'`
sudo \cp -f ${lan}${language}.txt ${lan}language.txt

# source /var/lib/dvswitch/dvs/var.txt > /dev/null 2>&1

# If update/upgrade is done without any configuration, finish process
if [ x${call_sign} = x ]; then

whiptail --msgbox "\

$sp12 $T392

$sp12 $T004

" 11 70 1

sudo ${DVS}dvs; exit 0

else

do_chk_ini_changed

fi
}

#-------------------------------------------------------------------------
do_chk_pkg() {
clear

# variable ${packages} is in func.txt
dvs_pkg=0
for pkg in ${packages}; do
        if [[ $PKGNAMES =~ $pkg ]]; then
        dvs_pkg=$((dvs_pkg+1))
        fi
done

packages=( $PKGNAMES )
all_pkg=${#packages[@]}
sys_pkg=$(($all_pkg - $dvs_pkg))

if (whiptail --title " $T305 " --yesno "\
$sp10 $T386 $all_pkg


$sp10 $T390
" 11 70);
        then do_upgrade
        else sudo ${DVS}dvs; exit 0
fi
}

#-------------------------------------------------------------------------
do_no_upgrade() {
clear

whiptail --msgbox "\

$sp12 $T383

$sp12 $T004

" 10 70 1

sudo ${DVS}dvs; exit 0
}

#============================================
# MAIN SCRIPT
#============================================

whiptail --msgbox "\

$sp10 $T380

" 9 70 1

clear
echo
echo
echo
echo "--------------------------------------------------------"
echo
echo "       $T382"
echo
echo "              $T006"
echo
echo "--------------------------------------------------------"
echo
sudo apt-get update
echo
echo "--------------------------------------------------------"
PKGNAMES=`/usr/bin/apt-get -q -y -s upgrade | /bin/grep ^Inst | /usr/bin/cut -d\  -f2 | /usr/bin/sort` > /dev/null 2>&1
if [[ -z "${PKGNAMES// }" ]];
then
do_no_upgrade
fi
echo
echo "              $T381"
echo
echo $PKGNAMES
echo
echo "--------------------------------------------------------"
echo
echo "               $T008"
read x
do_chk_pkg



#!/bin/bash

#===================================
SCRIPT_VERSION="Menu Script v.1.60"
SCRIPT_AUTHOR="HL5KY"
SCRIPT_DATE="10/15/2020"
#===================================

source /var/lib/dvswitch/dvs/var.txt


do_disable_temp_msg() {

sudo ${DVS}temp_msg.sh -n > /dev/null 2>&1

whiptail --msgbox "\

$sp27 $T003

$sp23 $T004

" 10 70 1

do_temp_msg
}


do_enable_temp_msg() {

sudo ${DVS}temp_msg.sh -y > /dev/null 2>&1

whiptail --msgbox "\

$sp27 $T003

$sp23 $T004

" 10 70 1

do_temp_msg
}

do_temp_msg() {
sel=$(whiptail --title " $T330 " --menu "\
\n
" 11 70 3 \
"1" "$T332" \
"2" "$T333" \
"3" "Back" \
3>&1 1>&2 2>&3)

if [ $? != 0 ]; then ${DVS}tools_menu.sh; exit 0; fi

case $sel in
1)
do_enable_temp_msg ;;
2)
do_disable_temp_msg ;;
3)
${DVS}tools_menu.sh; exit 0 ;;
esac
}


do_restart_service() {

clear

TERM=ansi whiptail --title "$T029" --infobox "$T006" 8 60

${DVS}88_restart.sh

whiptail --msgbox "\

$sp27 $T003

$sp23 $T004

" 10 70 1

clear
${DVS}tools_menu.sh; exit 0
}


# Tools Menu
OPTION=$(whiptail --title " $T300 " --menu "\
\n
" 17 110 9 \
"31 $T301     " "$T302" \
"32 $T303     " "$T304" \
"33 $T305     " "$T306" \
"34 $T307     " "$T308" \
"35 $T330     " "$T331" \
"36 $T311     " "$T312" \
"37 $T313     " "$T314" \
"38 $T315     " "$T316" \
"39 $T317     " "$T318" 3>&1 1>&2 2>&3)

if [ $? != 0 ]; then
        ${DVS}dvs; exit 0
fi

case $OPTION in
31\ *)${DVS}clone.sh ;;
32\ *)${DVS}config_ini.sh ;;
33\ *)${DVS}update_upgrade.sh ;;
34\ *)${DVS}language.sh ;;
35\ *)do_temp_msg ;;
36\ *)do_restart_service ;;
37\ *)sudo reboot ;;
38\ *)sudo shutdown -h now ;;
39\ *)${DVS}dvs; exit 0 ;;
esac

#2\ *)${DVS}system_monitor.sh ;;

clear

exit 0


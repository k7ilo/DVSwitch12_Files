#!/bin/bash

#===================================
SCRIPT_VERSION="Menu Script v.1.60"
SCRIPT_AUTHOR="HL5KY"
SCRIPT_DATE="10/15/2020"
#===================================

#sudo systemctl enable quantar_bridge

for service in mmdvm_bridge analog_bridge p25gateway nxdngateway ysfgateway ircddbgatewayd;
do
    sudo systemctl enable ${service}
done

sudo reboot

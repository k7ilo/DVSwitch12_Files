#!/bin/bash

#===================================
SCRIPT_VERSION="Menu Script v.1.60"
SCRIPT_AUTHOR="HL5KY"
SCRIPT_DATE="10/15/2020"
#===================================

#---------------------------------------------------------------------------------------------#
# The scripts "rpi-clone" is orginally written by Bill Wilson.                                #
# You can find more info. about rpi-clone on his github, https://github.com/billw2/rpi-clone  #
#---------------------------------------------------------------------------------------------#

source /var/lib/dvswitch/dvs/var.txt

if (whiptail --title " About rpi-clone " --yesno "\
\n
>$sp02 $T350

$sp09 $T351

$sp09 $T352
\n
>$sp02 $T353

$sp03 $T354

$sp03 $T355
\n
>$sp02 $T356

" 26 90); then :

	else clear; ${DVS}tools_menu.sh; exit 0
fi


clear


results=$(sudo find-removable)

for storage in sda sdb sdc sdd; do
if [[ $results =~ $storage ]]; then
drive=$storage
fi
done



if [ "$drive" != "" ]; then

	if (whiptail --title " Start rpi-clone " --yesno "\

$sp02 $T360 : $drive

$sp02 $T361

$sp02 $T005

$sp02 $T365
$sp07 $T366
$sp07 $T367
$sp07 $T368

	" 18 93);
	then
	clear
	sudo rpi-clone $drive
	echo
	echo "$T003"
	echo
	echo "$T004 .........."
	read x
	clear; 	${DVS}tools_menu.sh; exit 0
	fi

else

	whiptail --msgbox "\

$sp02 $T363

$sp02 $T364

	" 10 70 1

clear; ${DVS}tools_menu.sh; exit 0
fi

clear; ${DVS}tools_menu.sh; exit 0
exit 0

#!/bin/bash

#===================================
SCRIPT_VERSION="Menu Script v.1.60"
SCRIPT_AUTHOR="HL5KY"
SCRIPT_DATE="10/15/2020"
#===================================

source /var/lib/dvswitch/dvs/var.txt

# Get CPU temperature
if [ -f /sys/class/thermal/thermal_zone0/temp ] ; then
        if [ -x /usr/bin/bc ] ; then
                cpu=$(</sys/class/thermal/thermal_zone0/temp)
                cpu=$(echo "$cpu / 100 * 0.1" | bc)
                cpuf=$(echo "(1.8 * $cpu) + 32" | bc)
                TEMPERATURE="${cpu}'C (${cpuf}'F)"
#                echo "CPU temperature: $TEMPERATURE"
		${MESSAGE} "CPU temperature: $TEMPERATURE"
        fi
fi

exit 0



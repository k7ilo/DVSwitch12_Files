
#!/bin/bash

#===================================
SCRIPT_VERSION="Menu Script v.1.60"
SCRIPT_AUTHOR="HL5KY"
SCRIPT_DATE="10/15/2020"
#===================================

source /var/lib/dvswitch/dvs/var.txt


#do_languages-----------------------------------------------------
do_languages() {
clear

if [ "${language}" = "${sel_language}" ];
then
	whiptail --msgbox "\

               $T000
	" 9 70 1

        ${DVS}dvs; exit 0

#	${DVS}tools_menu.sh; exit 0

else
	sel_language=`echo ${sel_language} | tr '[A-Z]' '[a-z]'`

	sudo \cp -f ${lan}${sel_language}.txt ${lan}language.txt

	source /var/lib/dvswitch/dvs/var.txt

clear

TERM=ansi whiptail --title "$T029" --infobox "$T006" 8 60

P25=/opt/P25Gateway/P25Gateway.ini
NXDN=/opt/NXDNGateway/NXDNGateway.ini

for file in $P25 $NXDN; do
if [ $LN = ES ]; then sudo sed -i -e "/^Language=/ c Language=es_ES" ${file}
elif [ $LN = FR ]; then sudo sed -i -e "/^Language=/ c Language=fr_FR" ${file}
elif [ $LN = DE ]; then sudo sed -i -e "/^Language=/ c Language=de_DE" ${file}
elif [ $LN = IT ]; then sudo sed -i -e "/^Language=/ c Language=it_IT" ${file}
elif [ $LN = PL ]; then sudo sed -i -e "/^Language=/ c Language=pl_PL" ${file}
elif [ $LN = DK ]; then sudo sed -i -e "/^Language=/ c Language=dk_DK" ${file}
else sudo sed -i -e "/^Language=/ c Language=en_US" ${file}
fi
done

file=/etc/ircddbgateway
if [ $LN = ES ]; then sudo sed -i -e "/^language=/ c language=7" ${file}
elif [ $LN = FR ]; then sudo sed -i -e "/^language=/ c language=3" ${file}
elif [ $LN = DE ]; then sudo sed -i -e "/^language=/ c language=1" ${file}
elif [ $LN = IT ]; then sudo sed -i -e "/^language=/ c language=4" ${file}
elif [ $LN = PL ]; then sudo sed -i -e "/^language=/ c language=5" ${file}
elif [ $LN = DK ]; then sudo sed -i -e "/^language=/ c language=2" ${file}
else sudo sed -i -e "/^language=/ c language=6" ${file}
fi

for service in p25gateway nxdngateway ircddbgatewayd;
do sudo systemctl restart ${service} > /dev/null 2>&1
sleep 1
done

clear

	whiptail --msgbox "\

                           $T003

	" 9 70 1

	update_var startup_lan 73

	${DVS}dvs; exit 0
fi
}


#==== MIN_MENU ==========================================

# create an array with all the files inside a directory
array=(/var/lib/dvswitch/dvs/lan/*)

## iterate through array indexes to get 'file'
for file in "${array[@]}"; do
        lang="$(grep -w ^language= ${file})"
	lang_local="$(grep -w ^language_your_alphabet= ${file})"
# Ignore the template.txt and language.txt
        if [[ ! ${file} =~ "template" ]] && [[ ! $file =~ "language" ]]; then
                lng=$(echo $lang | cut -d'"' -f 2)
		lng_local=$(echo $lang_local | cut -d'"' -f 2)
                if [ x${lng} != x ]; then
                        no=$(($no+1))
                        lng="$no $lng "
			lng_local="$no $lng_local "
                        lng_list+=$lng
			lng_list_local+=$lng_local
                fi
        fi
done

# $lng_list -> language name in English
# $lng_list_local -> language name in local language

hgt=$(($no+13))

sel=$(whiptail --title " $T307 " --menu "\n
     We will add more later.

" $hgt 38 $no \
$lng_list_local \
3>&1 1>&2 2>&3)

if [ $? != 0 ]; then
        ${DVS}tools_menu.sh; exit 0
fi

right_text="${lng_list#*$sel }"

sel=$(($sel+1))

sel_language="${right_text%% $sel*}"


do_languages

clear

${DVS}tools_menu.sh; exit 0

exit 0





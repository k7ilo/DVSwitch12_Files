#!/bin/bash

#===================================
SCRIPT_VERSION="Menu Script v.1.61"
SCRIPT_AUTHOR="HL5KY"
SCRIPT_DATE="03/23/2021"
#===================================

source /var/lib/dvswitch/dvs/var.txt

###################################################
# do_config_MBini
###################################################

function do_config_MBini() {

	if [ "$1" = "return" ]; then
		sel_ntwk=${default_dmr_server}
	else
	        clear
		TERM=ansi whiptail --title "$T029" --infobox "$T006" 8 60
	fi


        if [ "${other1_name}" = "" ]; then other1_name="Other1"; fi
        if [ "${other2_name}" = "" ]; then other2_name="Other2"; fi


        if [ $sel_ntwk = $bm_name ]; then
                add=${bm_address}; port=${bm_port}; pswd=${bm_password}
        elif [ $sel_ntwk = $tgif_name ]; then
                add=${tgif_address}; port=${tgif_port}; pswd=${tgif_password}
        elif [ $sel_ntwk = $dmrplus_name ]; then
                add=${dmrplus_address}; port=${dmrplus_port}; pswd=${dmrplus_password}
        elif [ $sel_ntwk = $other1_name ]; then
                add=${other1_address}; port=${other1_port}; pswd=${other1_password}
        elif [ $sel_ntwk = $other2_name ]; then
                add=${other2_address}; port=${other2_port}; pswd=${other2_password}
        fi

	update_var default_dmr_server $sel_ntwk

        file=${MB}MMDVM_Bridge.ini
                $update_ini $file "DMR Network" Address ${add}
                $update_ini $file "DMR Network" Port ${port}
                $update_ini $file "DMR Network" Password ${pswd}
                sudo systemctl restart mmdvm_bridge

	if [ "$1" = "return" ]; then clear; exit 0; fi



#sudo nano ${MB}MMDVM_Bridge.ini

clear

whiptail --msgbox "\
\
$sp16 $T003\n
" 8 50 1

if [ "$1" = "change" ]; then
${DVS}adnl_dmr.sh change; exit 0
elif [ "$1" = "edit" ]; then
${DVS}adnl_dmr.sh edit; exit 0
fi
}

###################################################
# do_config_macro_advdmr
###################################################

function do_config_macro_advdmr() {

#        TERM=ansi whiptail --title "$T029" --infobox "$T006" 8 60

        if [ "${other1_name}" = "" ]; then other1_name="Other1"; fi
        if [ "${other2_name}" = "" ]; then other2_name="Other2"; fi
        networks="bm_address dmrplus_address tgif_address other1_address other2_address"
        name_list=(Brandmeister DMRPlus TGIF $other1_name $other2_name)
        name_cmd=(bm dmrplus tgif other1 other2)
        sp="    "

        for ntwk in ${networks}; do
                ntwk_add=${!ntwk}
                if [ x"${ntwk_add}" != x ]; then
                        no=$((no+1))
                        cmd=${name_cmd[$idx]}
                        ntwk=${name_list[$idx]}
                        line="*${cmd},.${sp}${ntwk}\n"
                        line_all+=${line}
                fi
                idx=$(($idx+1))
        done

        if [ -e ${AB}adv_dmr.txt ]; then
                file=${AB}adv_dmr.txt
                printf "$line_all" | sudo tee $file > /dev/null
                printf "*mainmenu,---- MAIN MENU ----" | sudo tee -a $file > /dev/null
        fi

	if [ "$1" = return ]; then clear; exit 0;
	elif [ "$1" = edit ]; then clear;
	whiptail --msgbox "\
\
$sp16 $T003\n
	" 8 50 1
	${DVS}adnl_dmr.sh edit; exit 0
	fi


	if [ "${default_check}" = "y" ]; then
		do_config_MBini edit
	else
		if (whiptail --title " $T400 " --yesno "\

$sp05 $T412

$sp05 $T005
		" 11 70); then
		do_config_MBini edit
		else clear; ${DVS}adnl_dmr.sh edit; exit 0
		fi
	fi
}

###################################################
# do_bm
###################################################

do_bm() {

if [ "$default_dmr_server" = "$bm_name" ]; then default_check=y; fi
sel_ntwk=${bm_name}

clear
if [ x${bm_address} = x ]; then

if (whiptail --title " $T405 " --yesno "\

$sp05 $T406
$sp05 --------------------------------
$sp05 $T408 = n/a
$sp05 $T409 = n/a
$sp05 $T410 = n/a
$sp05 --------------------------------
$sp05 $T416
" 17 50); then :
else ${DVS}adnl_dmr.sh edit; exit 0
fi

else

if (whiptail --title " $T405 " --yesno "\

$sp05 $T406
$sp05 --------------------------------
$sp05 $T408 = ${bm_address}
$sp05 $T409 = ${bm_password}
$sp05 $T410 = ${bm_port}
$sp05 --------------------------------
$sp05 $T415
" 17 70); then :
else ${DVS}adnl_dmr.sh edit; exit 0
fi

fi

#------- Create bm.list from DMR_Hotsts.txt ----------------------------------------------

sudo \cp -f ${DATA}bm.list ${DATA}bm.list_old > /dev/null 2>&1

# get the records starting "BM_" from DMR_Hosts.txt and create bm.list_1
sudo grep -i -e "^BM_" ${dir_host}DMR_Hosts.txt | sudo tee ${DATA}bm.list_1 > /dev/null 2>&1

# cut the first column from bm.list_1
sudo cut -f1 ${DATA}bm.list_1 | sudo tee ${DATA}bm.list_2 > /dev/null 2>&1

# add a new line "===Type_in===" in the last line of bm.list
#sudo bash -c 'echo ===Type_in=== >> /var/lib/dvswitch/dvs/bm.list' > /dev/null 2>&1

# number all the lines
sudo nl ${DATA}bm.list_2 | sudo tee ${DATA}bm.list > /dev/null 2>&1

# verify bm.list is valid
file=${DATA}bm.list
if [[ -z `sudo grep "BM_" $file` ]]; then
sudo \cp -f ${DATA}bm.list_old ${DATA}bm.list > /dev/null 2>&1
fi

sudo rm ${DATA}bm.list_* > /dev/null 2>&1

#------- Create bm.list from DMR_Hotsts.txt ----------------------------------------------

value=$(cat ${DATA}bm.list)
num=$(whiptail --title "Local Brandmeister Master Server" --menu "\
\n
      $T163
" 30 42 20 ${value} 3>&1 1>&2 2>&3)
if [ $? != 0 ]; then ${DVS}adnl_dmr.sh edit; exit 0; fi

sel_line=$(sudo awk '$1 == '"$num"' { print $2 }' ${DATA}bm.list)

# bm_master=
bm_address=$(awk '$1 == "'${sel_line}'" { print $3 }' ${dir_host}DMR_Hosts.txt)

# if the user makes ${bm_address} blank, and ${default_dmr_server} is Brandmeister, then back to MENU
if [ "${bm_address}" = "" ] && [ "${default_check}" = "y" ]; then
whiptail --msgbox "\

$sp10 ${sel_ntwk} $T421

$sp10 $T422
" 11 70 1
${DVS}adnl_dmr.sh edit; exit 0;
fi

bm_password=$(awk '$1 == "'${sel_line}'" { print $4 }' ${dir_host}DMR_Hosts.txt)
bm_port=$(awk '$1 == "'${sel_line}'" { print $5 }' ${dir_host}DMR_Hosts.txt)

bm_password=$(whiptail --title "$T009" --inputbox "$T162" 10 60 ${bm_password} 3>&1 1>&2 2>&3)
if [ $? != 0 ]; then ${DVS}adnl_dmr.sh edit; exit 0; fi


for file in ${DATA}var.txt
do
        update_var bm_address ${bm_address}
        update_var bm_password ${bm_password}
        update_var bm_port ${bm_port}
done


if [ "${bm_address}" = "" ]; then
do_config_macro_advdmr edit
fi

sel_ntwk=${bm_name}; clear
do_config_macro_advdmr
}

###################################################
# do_dmrplus
###################################################

do_dmrplus() {

if [ "$default_dmr_server" = "$dmrplus_name" ]; then default_check=y; fi
sel_ntwk=${dmrplus_name}

clear
if [ x${dmrplus_address} = x ]; then

if (whiptail --title " $T401 " --yesno "\

$sp05 $T406
$sp05 --------------------------------
$sp05 $T408 = n/a
$sp05 $T409 = n/a
$sp05 $T410 = n/a
$sp05 --------------------------------
$sp05 $T416
" 17 50); then :
else ${DVS}adnl_dmr.sh edit; exit 0
fi

else

if (whiptail --title " $T401 " --yesno "\

$sp05 $T406
$sp05 --------------------------------
$sp05 $T408 = ${dmrplus_address}
$sp05 $T409 = ${dmrplus_password}
$sp05 $T410 = ${dmrplus_port}
$sp05 --------------------------------
$sp05 $T415
" 17 50); then :
else ${DVS}adnl_dmr.sh edit ; exit 0
fi

fi

#--- Create dmrplus.list from DMR_Hotsts.txt ----------------------------------------------

sudo \cp -f ${DATA}dmrplus.list ${DATA}dmrplus.list_old > /dev/null 2>&1

# get the records starting "DMR+_" from DMR_Hosts.txt and create dmrplus.list_1
sudo grep -i -e "^DMR+_" ${dir_host}DMR_Hosts.txt | sudo tee ${DATA}dmrplus.list_1 > /dev/null 2>&1

# cut the first column from dmrplus.list_1
sudo cut -f1 ${DATA}dmrplus.list_1 | sudo tee ${DATA}dmrplus.list_2 > /dev/null 2>&1

# add a new line "===Type_in===" in the last line of dmrplus.list
# sudo bash -c 'echo ===Type_in=== >> /var/lib/dvswitch/dvs/dmrplus.list' > /dev/null 2>&1

# number all the lines
sudo nl ${DATA}dmrplus.list_2 | sudo tee ${DATA}dmrplus.list > /dev/null 2>&1

# verify dmrplus.list is valid
file=${DATA}dmrplus.list
if [[ -z `sudo grep "DMR+_IPSC2-N" $file` ]]; then
sudo \cp -f ${DATA}bm.list_old ${DATA}bm.list > /dev/null 2>&1
fi

sudo rm ${DATA}dmrplus.list_* > /dev/null 2>&1

#--- Create dmrplus.list from DMR_Hotsts.txt ----------------------------------------------


value=$(sudo cat ${DATA}dmrplus.list)
        num=$(whiptail --title " $T401 " --menu "\
        \n
      $T280
        " 30 45 20 ${value} 3>&1 1>&2 2>&3)

if [ $? != 0 ]; then ${DVS}adnl_dmr.sh edit; exit 0; fi

sel_line=$(sudo awk '$1 == '"$num"' { print $2 }' ${DATA}dmrplus.list)

dmrplus_address=$(awk '$1 == "'${sel_line}'" { print $3 }' ${dir_host}DMR_Hosts.txt)
dmrplus_password=$(awk '$1 == "'${sel_line}'" { print $4 }' ${dir_host}DMR_Hosts.txt)
dmrplus_port=$(awk '$1 == "'${sel_line}'" { print $5 }' ${dir_host}DMR_Hosts.txt)

# if the user makes ${dmrplus_address} blank, and ${default_dmr_server} is DMRPlus, then back to MENU
if [ "${dmrplus_address}" = "" ] && [ "${default_check}" = "y" ]; then
whiptail --msgbox "\

$sp10 ${sel_ntwk} $T421

$sp10 $T422
" 11 70 1
${DVS}adnl_dmr.sh edit; exit 0;
fi


for file in ${DATA}var.txt
do
        update_var dmrplus_address ${dmrplus_address}
        update_var dmrplus_password ${dmrplus_password}
        update_var dmrplus_port ${dmrplus_port}
done


if [ "${dmrplus_address}" = "" ]; then
do_config_macro_advdmr edit
fi

sel_ntwk=${dmrplus_name}; clear
do_config_macro_advdmr
}

###################################################
# do_tgif
###################################################

do_tgif() {

if [ "$default_dmr_server" = "$tgif_name" ]; then default_check=y; fi
sel_ntwk=${tgif_name}

clear
if [ x${tgif_address} = x ]; then

if (whiptail --title " $T402 " --yesno "\

$sp05 $T406
$sp05 --------------------------------
$sp05 $T407 = n/a
$sp05 $T408 = n/a
$sp05 $T409 = n/a
$sp05 $T410 = n/a
$sp05 --------------------------------
$sp05 $T416
" 17 50); then :
else ${DVS}adnl_dmr.sh edit ; exit 0
fi

else

if (whiptail --title " $T402 " --yesno "\

$sp05 $T406
$sp05 --------------------------------
$sp05 $T408 = ${tgif_address}
$sp05 $T409 = ${tgif_password}
$sp05 $T410 = ${tgif_port}
$sp05 --------------------------------
$sp05 $T415
" 17 50); then :
else ${DVS}adnl_dmr.sh edit; exit 0
fi

fi


tgif_address=$(whiptail --title "$T009" --inputbox "$T282" 10 60 ${tgif_address} 3>&1 1>&2 2>&3)
if [ $? != 0 ]; then ${DVS}adnl_dmr.sh edit; exit 0; fi

# if the user makes ${tgif_address} blank, and ${default_dmr_server} is TGIF, then back to MENU
if [ "${tgif_address}" = "" ] && [ "${default_check}" = "y" ]; then
whiptail --msgbox "\

$sp10 ${sel_ntwk} $T421

$sp10 $T422
" 11 70 1
${DVS}adnl_dmr.sh edit; exit 0;
fi


tgif_password=$(whiptail --title "$T009" --inputbox "$T283" 10 60 ${tgif_password} 3>&1 1>&2 2>&3)
if [ $? != 0 ]; then ${DVS}adnl_dmr.sh edit; exit 0; fi

tgif_port=$(whiptail --title "$T009" --inputbox "$T284" 10 60 ${tgif_port} 3>&1 1>&2 2>&3)
if [ $? != 0 ]; then ${DVS}adnl_dmr.sh edit; exit 0; fi

# if the user makes ${tgif} blank, and ${default_dmr_server} is TGIF, then back to MENU
if [ "${tgif_address}" = "" ] && [ "${default_check}" = "y" ]; then
whiptail --msgbox "\

$sp10 ${sel_ntwk} $T421

$sp10 $T422
" 11 70 1
${DVS}adnl_dmr.sh edit; exit 0;
fi


for file in ${DATA}var.txt
do
        update_var tgif_address ${tgif_address}
        update_var tgif_password ${tgif_password}
	update_var tgif_port ${tgif_port}
done


if [ "${tgif_address}" = "" ]; then
do_config_macro_advdmr edit
fi

sel_ntwk=${tgif_name}; clear
do_config_macro_advdmr
}

###################################################
# do_other1
###################################################

do_other1() {

if [ "${default_dmr_server}" = "${other1_name}" ]; then default_check=y; fi
sel_ntwk=${other1_name}

clear
if [ x${other1_address} = x ]; then

if (whiptail --title " $T403 " --yesno "\

$sp05 $T406
$sp05 --------------------------------
$sp05 $T407 = n/a
$sp05 $T408 = n/a
$sp05 $T409 = n/a
$sp05 $T410 = n/a
$sp05 --------------------------------
$sp05 $T416
" 17 50); then :
else ${DVS}adnl_dmr.sh edit; exit 0
fi

else

if (whiptail --title " $T403 " --yesno "\

$sp05 $T406
$sp05 --------------------------------
$sp05 $T407 = ${other1_name}
$sp05 $T408 = ${other1_address}
$sp05 $T409 = ${other1_password}
$sp05 $T410 = ${other1_port}
$sp05 --------------------------------
$sp05 $T415
" 17 50); then :
else ${DVS}adnl_dmr.sh edit; exit 0
fi

fi


other1_name=$(whiptail --title "$T009" --inputbox "$T286" 10 60 ${other1_name} 3>&1 1>&2 2>&3)
if [ $? != 0 ]; then ${DVS}adnl_dmr.sh edit; exit 0; fi

other1_address=$(whiptail --title "$T009" --inputbox "$T287" 10 60 ${other1_address} 3>&1 1>&2 2>&3)
if [ $? != 0 ]; then ${DVS}adnl_dmr.sh edit; exit 0; fi


# if the user makes ${other1_address} blank, and ${default_dmr_server} is Other1, then back to MENU
if [ "${other1_address}" = "" ] && [ "${default_check}" = "y" ]; then
whiptail --msgbox "\

$sp10 ${sel_ntwk} $T421

$sp10 $T422
" 11 70 1
${DVS}adnl_dmr.sh edit; exit 0;
fi


other1_password=$(whiptail --title "$T009" --inputbox "$T288" 10 60 ${other1_password} 3>&1 1>&2 2>&3)
if [ $? != 0 ]; then ${DVS}adnl_dmr.sh edit; exit 0; fi

other1_port=$(whiptail --title "$T009" --inputbox "$T289" 10 60 ${other1_port} 3>&1 1>&2 2>&3)
if [ $? != 0 ]; then ${DVS}adnl_dmr.sh edit; exit 0; fi


for file in ${DATA}var.txt
do
        update_var other1_name ${other1_name}
        update_var other1_address ${other1_address}
        update_var other1_password ${other1_password}
        update_var other1_port ${other1_port}
done


if [ "${other1_address}" = "" ]; then
do_config_macro_advdmr edit
fi

sel_ntwk=${other1_name}; clear
do_config_macro_advdmr
}

###################################################
# do_other2
###################################################

do_other2() {

if [ "$default_dmr_server" = "$other2_name" ]; then default_check=y; fi
sel_ntwk=${other2_name}

clear
if [ x${other2_address} = x ]; then

if (whiptail --title " $T404 " --yesno "\

$sp05 $T406
$sp05 --------------------------------
$sp05 $T407 = n/a
$sp05 $T408 = n/a
$sp05 $T409 = n/a
$sp05 $T410 = n/a
$sp05 --------------------------------
$sp05 $T416
" 17 50); then :
else ${DVS}adnl_dmr.sh edit; exit 0
fi

else

if (whiptail --title " $T404 " --yesno "\

$sp05 $T406
$sp05 --------------------------------
$sp05 $T407 = ${other2_name}
$sp05 $T408 = ${other2_address}
$sp05 $T409 = ${other2_password}
$sp05 $T410 = ${other2_port}
$sp05 --------------------------------
$sp05 $T415
" 17 50); then :
else ${DVS}adnl_dmr.sh edit; exit 0
fi

fi


other2_name=$(whiptail --title "$T009" --inputbox "$T286" 10 60 ${other2_name} 3>&1 1>&2 2>&3)
if [ $? != 0 ]; then ${DVS}adnl_dmr.sh edit; exit 0; fi

other2_address=$(whiptail --title "$T009" --inputbox "$T287" 10 60 ${other2_address} 3>&1 1>&2 2>&3)
if [ $? != 0 ]; then ${DVS}adnl_dmr.sh edit; exit 0; fi

# if the user makes ${other2_address} blank, and ${default_dmr_server} is Other2, then back to MENU
if [ "${other2_address}" = "" ] && [ "${default_check}" = "y" ]; then
whiptail --msgbox "\

$sp10 ${sel_ntwk} $T421

$sp10 $T422
" 11 70 1
${DVS}adnl_dmr.sh edit; exit 0;
fi

other2_password=$(whiptail --title "$T009" --inputbox "$T288" 10 60 ${other2_password} 3>&1 1>&2 2>&3)
if [ $? != 0 ]; then ${DVS}adnl_dmr.sh edit; exit 0; fi

other2_port=$(whiptail --title "$T009" --inputbox "$T289" 10 60 ${other2_port} 3>&1 1>&2 2>&3)
if [ $? != 0 ]; then ${DVS}adnl_dmr.sh edit; exit 0; fi


for file in ${DATA}var.txt
do
        update_var other2_name ${other2_name}
        update_var other2_address ${other2_address}
        update_var other2_password ${other2_password}
        update_var other2_port ${other2_port}
done


if [ "${other2_address}" = "" ]; then
do_config_macro_advdmr edit
fi

sel_ntwk=${other2_name}; clear
do_config_macro_advdmr
}

###################################################
# do_config_server_menu
###################################################

function do_config_server_menu() {

if [ "$other1_name" = "" ]; then menu_name_other1=$T403; else menu_name_other1=$other1_name; fi
if [ "$other2_name" = "" ]; then menu_name_other2=$T404; else menu_name_other2=$other2_name; fi

clear

sel=$(whiptail --title " $T400 " --menu "\
\n
$sp08 $T418

" 16 45 6 \
"1" "$T405" \
"2" "$T401" \
"3" "$T402" \
"4" "$menu_name_other1" \
"5" "$menu_name_other2" \
"6" "$T317" \
3>&1 1>&2 2>&3)

if [ $? != 0 ]; then ${DVS}adnl_dmr.sh; exit 0; fi

case $sel in
1)
do_bm ;;
2)
do_dmrplus ;;
3)
do_tgif ;;
4)
do_other1 ;;
5)
do_other2 ;;
6)
${DVS}adnl_dmr.sh; exit 0 ;;
esac
}

###################################################
# do_change_server_menu
###################################################

function do_change_server_menu() {

        if [ "${other1_name}" = "" ]; then other1_name="Other1"; fi
        if [ "${other2_name}" = "" ]; then other2_name="Other2"; fi
        networks="bm_address dmrplus_address tgif_address other1_address other2_address"
        name_list=(Brandmeister DMRPlus TGIF $other1_name $other2_name)

        file=${MB}MMDVM_Bridge.ini

        for ntwk in ${networks}; do
                ntwk_add=${!ntwk}
		if [ "${ntwk_add}" != "" ]; then
                        no=$((no+1))
                        ntwk=${name_list[$idx]}
                        ntwk_no="$no $ntwk "
                        ntwk_name_list+="${ntwk_no} "
### check if ${ntwk_add} matches the DMR_address in MB.ini, then that is a default or current DMR server
### the result will be seen in the menu list
### ${default_dmr_server} should be same with the result and can be replaced
#                        if [[ ! -z `sudo grep ${ntwk_add} $file` ]]; then
#                                default_ntwk=${name_list[$idx]}
#                        fi
                fi
		idx=$(($idx+1))
        done


        if [ "${ntwk_name_list}" != "" ]; then

                no=$((no+1))
                hgt=$(($no+12))
                ntwk_name_list+="$no $T317 "


                clear
                sel=$(whiptail --title " $T400 " --menu "\n
$sp05 $T417

$sp05 $T419: $default_dmr_server

                " $hgt 45 $no \
                $ntwk_name_list \
                3>&1 1>&2 2>&3)

                if [ $? != 0 ] || [ $sel = $no ]; then ${DVS}adnl_dmr.sh; exit 0; fi

                right_text="${ntwk_name_list#*$sel }"
                sel=$(($sel+1))
                sel_ntwk="${right_text%% $sel*}"
	    #sel_ntwk=$(echo ${sel_ntwk} | tr -d ' ')
                do_config_MBini change
        else

                clear
                whiptail --msgbox "\
\

$sp05 $T423

                " 9 60 1
                ${DVS}adnl_dmr.sh; exit 0

        fi
}

###################################################
# MAIN
###################################################

if [ "$1" = "advdmr_return" ]; then
	do_config_macro_advdmr return
elif [ "$1" = "MBini_return" ]; then
        do_config_MBini return
elif [ "$1" = "change" ]; then
	do_change_server_menu
elif [ "$1" = "edit" ]; then
	do_config_server_menu
fi

sel=$(whiptail --title " $T400 " --menu "\
\n
" 11 45 3 \
"1" "$T417" \
"2" "$T418" \
"3" "$T317" \
3>&1 1>&2 2>&3)

if [ $? != 0 ]; then ${DVS}adv_config_menu.sh; exit 0; fi

case $sel in
1)
do_change_server_menu ;;
2)
do_config_server_menu ;;
3)
${DVS}adv_config_menu.sh; exit 0 ;;
esac

clear

exit 0

#!/bin/bash

#===================================
SCRIPT_VERSION="Menu Script v.1.61"
SCRIPT_AUTHOR="HL5KY"
SCRIPT_DATE="03/23/2021"
#===================================

source /var/lib/dvswitch/dvs/var.txt

############################################
#  do_enable_gpio_uart
############################################
function do_enable_gpio_uart() {

# Remove serial console from cmdline.txt and add enable_uart to config.txt
sudo raspi-config nonint do_serial 2

# Check for existence of bluetooth and move it to the mini uart.
if sudo rfkill --noheadings --output TYPE | grep -q "bluetooth"; then
     if ! sudo grep -q "dtoverlay miniuart-bt" /boot/config.txt; then
         echo "dtoverlay miniuart-bt" | sudo tee -a /boot/config.txt
     fi
fi
}

############################################
#  do_config
############################################

function do_config() {

# Start of progress bar
{
# -----------------------------------------
let "complete=complete+20"
echo -e "$complete"

#-----------------------------------------------------------
update_var call_sign ${call_sign}
update_var dmr_id ${dmr_id}
update_var rpt_id ${rpt_id}
rpt_id_2=$(($rpt_id+10))
rpt_id_3=$(($rpt_id+20))
update_var rpt_id_2 ${rpt_id_2}
update_var rpt_id_3 ${rpt_id_3}
update_var module ${module}
update_var nxdn_id ${nxdn_id}
update_var usrp_port ${usrp_port}
#-----------------------------------------
let "complete=complete+20"
echo -e "$complete"
update_var bm_master ${bm_master}
update_var bm_address ${bm_address}
update_var bm_password ${bm_password}
update_var bm_port ${bm_port}
update_var ambe_option ${ambe_option}
update_var ambe_server ${ambe_server}
update_var ambe_rxport ${ambe_rxport}
update_var ambe_baud ${ambe_baud}
#-----------------------------------------
let "complete=complete+10"
echo -e "$complete"


#-----------------------------------------------------------

do_KR() {
	sudo ${DVS}temp_msg.sh -y

	sudo \mv -f ${AB}dvsm.macro ${AB}dvsm.basic
	sudo \cp -f ${adv}dvsm.* ${AB}
	sudo chmod +x ${AB}dvsm.sh
        if [ -d ${adv}${LN} ]; then
		sudo \cp -f ${adv}${LN}/*.* ${AB}
	fi

	update_var dmrplus_address ipsc.dvham.com
	update_var dmrplus_password PASSWORD
	update_var dmrplus_port 55555
}

do_tgdb_file_copy() {
	if [ -d ${tgdb}${LN} ]; then
        	sudo \cp -f ${tgdb}${LN}/* ${tgdb}
	else
        	sudo \cp -f ${tgdb}EN/* ${tgdb}
	fi
}

do_AB_ini_audio_edit() {
        file="${AB}Analog_Bridge.ini"
        sudo sed -i -e "/^usrpAudio/ c usrpAudio = AUDIO_USE_GAIN              ; Digital -> Analog (AUDIO_UNITY, AUDIO_USE_GAIN, AUDIO_USE_AGC)" $file
        sudo sed -i -e "/^usrpGain/ c usrpGain = ${usrpGain}                         ; Gain factor when usrpAudio = AUDIO_USE_GAIN (0.0 to 5.0) (1.0 = AUDIO_UNITY)" $file
        sudo sed -i -e "/^tlvAudio/ c tlvAudio = AUDIO_USE_GAIN               ; Analog -> Digital (AUDIO_UNITY, AUDIO_USE_GAIN, AUDIO_BPF)" $file
        sudo sed -i -e "/^tlvGain/ c tlvGain = ${txgain_dmr}                          ; Gain factor when tlvAudio = AUDIO_USE_GAIN (0.0 to 5.0) (1.0 = AUDIO_UNITY)" $file
}
#-----------------------------------------------------------

if [ "${first_time_instl}" = "1" ]; then
	if [ ${dmr_id:0:3} = 450 -o "${LN}" = "KR" ]; then
		LN="KR"
		do_KR
		do_tgdb_file_copy
	        do_AB_ini_audio_edit
	else
                do_tgdb_file_copy
#                do_AB_ini_audio_edit
	fi
# update DMR server list on the macro, adv_dmr.txt
${DVS}adnl_dmr.sh advdmr_return

update_var first_time_instl 73

fi

#-----------------------------------------------------------
let "complete=complete+20"
echo -e "$complete"

file=${AB}Analog_Bridge.ini
	sudo sed -i -e "/^useEmulator =/ c useEmulator = true                      ; Use the MD380 AMBE emulator for AMBE72 (DMR/YSFN/NXDN)" $file
	sudo sed -i -e "/^gatewayDmrId =/ c gatewayDmrId = ${dmr_id}                  ; ID to use when transmitting from Analog_Bridge 7 digit ID" $file
	sudo sed -i -e "/^repeaterID =/ c repeaterID = ${rpt_id}                  ; ID of source repeater 7 digit ID plus 2 digit SSID" $file
	if [ x${usrp_port} != x ]; then
		sudo sed -i -e "/Transmit USRP/ c txPort = ${usrp_port}                          ; Transmit USRP frames on this port" $file
		sudo sed -i -e "/Listen for USRP/ c rxPort = ${usrp_port}                          ; Listen for USRP frames on this port" $file
	fi
#-----------------------------------------------------------
#-----------------------------------------

file=${MB}MMDVM_Bridge.ini
	sudo sed -i -e "/^Callsign=/ c Callsign=${call_sign}" ${file}
	sudo sed -i -e "/^Enable=/ c Enable=1" $file
	sudo sed -i -e "/^Module=/ c Module=${module}" ${file}
	$update_ini $file "DMR Network" Address ${bm_address}
	$update_ini $file "DMR Network" Password ${bm_password}
	$update_ini $file "DMR Network" Port ${bm_port}
        #sudo sed -i -e "/^Address=/ c Address=${bm_address}" ${file}
        #sudo sed -i -e "/^Password=/ c Password=${bm_password}" ${file}
	General=$(grep -n "\[General" ${MB}MMDVM_Bridge.ini | cut -d':' -f1)
	id_line=`expr $General + 2`
	sudo sed -i -e "${id_line}s/.*/Id=${rpt_id}/" ${file}

	NXDN=$(grep -n "\[NXDN\]" ${MB}MMDVM_Bridge.ini | cut -d':' -f1)
	id_line=`expr $NXDN + 3`
        sudo sed -i -e "${id_line}s/.*/Id=${nxdn_id}/" ${file}
#-----------------------------------------
let "complete=complete+10"
echo -e "$complete"

# update default_DMR_server according to var.txt, specially needed on the reconfiguration of <initial configuration>
sudo ${DVS}adnl_dmr.sh MBini_return > /dev/null


file=${MB}MMDVM_Bridge.ini

function edit_info() {
if [ "$2" != "" ]; then
        sudo sed -i -e "/^$1=/ c $1=$2" ${file}
fi
}

edit_info RXFrequency ${rx_freq}
edit_info TXFrequency ${tx_freq}
edit_info Power ${pwr}
edit_info Latitude ${lat}
edit_info Longitude ${lon}
edit_info Height ${hgt}
edit_info Location "${lctn}"
edit_info Description "${desc}"
edit_info URL ${url}

#-----------------------------------------------------------
#-----------------------------------------
let "complete=complete+10"
echo -e "$complete"

file=/opt/NXDNGateway/NXDNGateway.ini
        sudo sed -i -e "/^Callsign=/ c Callsign=${call_sign}" ${file}
#-----------------------------------------------------------
file=/opt/P25Gateway/P25Gateway.ini
        sudo sed -i -e "/^Callsign=/ c Callsign=${call_sign}" ${file}
#-----------------------------------------------------------
echo "      -----------------------------------------"
ysf="/opt/YSFGateway/"
file=/opt/YSFGateway/YSFGateway.ini
        sudo sed -i -e "/^Callsign=/ c Callsign=${call_sign}" ${file}
	sudo sed -i -e "/^Id=/ c Id=${rpt_id}" $file
#-----------------------------------------------------------
file=/opt/Quantar_Bridge/Quantar_Bridge.ini
        sudo sed -i -e "/^Address =/ c Address = 127.0.0.1             ; Address to send IMBE TLV frames to (export)" ${file}
#-----------------------------------------------------------
#-----------------------------------------

file=/etc/ircddbgateway
        sudo sed -i -e "/^gatewayCallsign=/ c gatewayCallsign=${call_sign}" ${file}
        sudo sed -i -e "/^repeaterCall1=/ c repeaterCall1=${call_sign}" ${file}
	sudo sed -i -e "/^repeaterBand1=/ c repeaterBand1=${module}" ${file}
        sudo sed -i -e "/^ircddbUsername=/ c ircddbUsername=${call_sign}" ${file}
        sudo sed -i -e "/^ircddbPassword=/ c ircddbPassword=${call_sign}" ${file}
        sudo sed -i -e "/^dplusEnabled=/ c dplusEnabled=1" $file
        sudo sed -i -e "/^dplusLogin=/ c dplusLogin=${call_sign}" ${file}
        sudo sed -i -e "/^language=/ c language=0" $file
        sudo sed -i -e "/^logEnabled=/ c logEnabled=1" $file
#	sudo sed -i -e "/^remoteEnabled=/ c remoteEnabled=1" $file
	sudo sed -i -e "/^remotePassword=/ c remotePassword=${rpt_id}" $file
#	sudo sed -i -e "/^remotePort=/ c remotePort=54321" $file
#-----------------------------------------------------------
#-----------------------------------------

#file=/var/www/html/include/config.php
#	sudo sed -i -e "/^define(\"ABINFO\"/ c define(\"ABINFO\", \"${usrp_port}\");" $file

file=/root/".Remote Control"
	sudo sed -i -e "/^password/ c password=${rpt_id}" "$file"

let "complete=complete+10"
echo -e "$complete"

# AMBE
ambe_add="address = ${ambe_server}               ; IP address of AMBEServer"
ambe_add_default="address = 127.0.0.1                 ; IP address of AMBEServer"
ambe_port="rxPort = ${ambe_rxport}                       ; Port of AMBEServer"
dvce_usb="address = /dev/ttyUSB0              ; Device of DV3000U on this machine"
dvce_ama="address = /dev/ttyAMA0                ; Device of DV3000U on this machine"
baud="baud = ${ambe_baud}                       ; Baud rate of the dongle (230400 or 460800)"
serial="serial = true                       ; Use serial=true for direct connect or serial=false for AMBEServer"

file=${AB}Analog_Bridge.ini

if [ "$ambe_option" = "1" ]; then
          sudo sed -i -e "/IP address of AMBE/ c $ambe_add" $file
          sudo sed -i -e "/Port of AMBE/ c $ambe_port" $file
          sudo sed -i -e "/Device of DV3000/ c ; $dvce_usb" $file
          sudo sed -i -e "/Baud rate/ c ; $baud" $file
          sudo sed -i -e "/Use serial/ c ; $serial" $file

elif [ "$ambe_option" = "2" ]; then
          sudo sed -i -e "/IP address of AMBE/ c ; $ambe_add_default" $file
          sudo sed -i -e "/Port of AMBE/ c ; $ambe_port" $file
          sudo sed -i -e "/Device of DV3000/ c $dvce_usb" $file
          sudo sed -i -e "/Baud rate/ c $baud" $file
          sudo sed -i -e "/Use serial/ c $serial" $file

elif [ "$ambe_option" = "3" ]; then
          sudo sed -i -e "/IP address of AMBE/ c ; $ambe_add_default" $file
          sudo sed -i -e "/Port of AMBE/ c ; $ambe_port" $file
          sudo sed -i -e "/Device of DV3000/ c $dvce_ama" $file
          sudo sed -i -e "/Baud rate/ c $baud" $file
          sudo sed -i -e "/Use serial/ c $serial" $file

elif [ "$ambe_option" = "4" ]; then
          sudo sed -i -e "/IP address of AMBE/ c ; $ambe_add_default" $file
          sudo sed -i -e "/Port of AMBE/ c ; $ambe_port" $file
          sudo sed -i -e "/Device of DV3000/ c ; $dvce_usb" $file
          sudo sed -i -e "/Baud rate/ c ; $baud" $file
          sudo sed -i -e "/Use serial/ c ; $serial" $file
fi

#-----------------------------------------

# variable ${services} is in func.txt
sudo systemctl restart $services > /dev/null 2>&1
#-----------------------------------------

} |whiptail --title "$T185" --gauge "$T006..." 6 60 0

#-----------------------------------------

if [ "$1" = "return" ]; then clear; exit 0;

elif [ "$ambe_option" = "3" ]; then
do_enable_gpio_uart

whiptail --msgbox "\
$sp11 $T190

$sp11 $T191

$sp11 $T192

" 11 70 1
clear; sudo reboot; exit 0


else
whiptail --msgbox "\
$sp11 $T190

$sp11 $T194

$sp11 $T004

" 11 70 1
clear; ${DVS}dvs; exit 0
fi

}

############################################
#  MAIN SCRIPT
############################################

if [ "$1" = "dvsb" -o "$1" = "update" -o "$1" = "return" ]; then
	clear
	do_config return
fi


# Initial Configuration
if (whiptail --title " $T154 " --yesno "\
$T155

$T005
" 10 80); then :
	else ${DVS}dvs; exit 0
fi
#

#if [ ${call_sign} != "N0CALL" ] || [ x${call_sign} != x ]; then
## Previous Configuration notice
#if (whiptail --title " $T150" --yesno "\
#$T151 ${call_sign}/${dmr_id}

#$T152

#$T005
#" 12 80); then :
#        else ${DVS}dvs; exit 0
#if [ $? != 0 ]; then ${DVS}dvs; exit 0; fi
#fi
#fi
##


call_sign=$(whiptail --title "$T009" --inputbox "$T160" 10 60 ${call_sign} 3>&1 1>&2 2>&3)
if [ $? != 0 ]; then ${DVS}dvs; exit 0; fi
#

call_sign=`echo ${call_sign} | tr '[a-z]' '[A-Z]'`

if [ x${dmr_id} != x ]; then
dmr_id_old=${dmr_id}
else dmr_id_old=none
fi

dmr_id=$(whiptail --title "$T009" --inputbox "CCS7/DMR ID ?" 10 60 ${dmr_id} 3>&1 1>&2 2>&3)
if [ $? != 0 ]; then ${DVS}dvs; exit 0; fi
#

until [ ${#dmr_id} = 7 ]; do
dmr_id=$(whiptail --title "$T009" --inputbox "CCS7/DMR ID ?  ($T165)" 10 60 ${dmr_id} 3>&1 1>&2 2>&3)
if [ $? != 0 ]; then ${DVS}dvs; exit 0; fi
done


if [ ${dmr_id_old} = ${dmr_id} ]; then
rpt_id_temp=$(whiptail --title "$T009" --inputbox "CCS7/DMR ID + $T166 (00 ~99) ?" 10 60 ${rpt_id} 3>&1 1>&2 2>&3)
else
rpt_id_temp=$(whiptail --title "$T009" --inputbox "CCS7/DMR ID + $T166 (00 ~99) ?" 10 60 ${dmr_id}11 3>&1 1>&2 2>&3)
fi
if [ $? != 0 ]; then ${DVS}dvs; exit 0; fi


until [ ${#rpt_id_temp} = 9 ]; do
if [ ${dmr_id_old} = ${dmr_id} ]; then
rpt_id_temp=$(whiptail --title "$T009" --inputbox "CCS7/DMR ID + $T166 ($T167)" 10 70 ${rpt_id} 3>&1 1>&2 2>&3)
else
rpt_id_temp=$(whiptail --title "$T009" --inputbox "CCS7/DMR ID + $T166 ($T167)" 10 70 ${dmr_id}11 3>&1 1>&2 2>&3)
fi
if [ $? != 0 ]; then ${DVS}dvs; exit 0; fi
done

rpt_id=${rpt_id_temp}


if [ x${module} = x ]; then
	if [ ${dmr_id:0:3} = 450 -o "${LN}" = "KR" ]; then
	module=S
	else module=B
	fi
fi

module=$(whiptail --title "$T009" --inputbox "Dstar module ? (A~Z) ? " 10 60 ${module} 3>&1 1>&2 2>&3)
if [ $? != 0 ]; then ${DVS}dvs; exit 0; fi
#

nxdn_id=$(whiptail --title "$T009" --inputbox "$T161" 10 60 ${nxdn_id} 3>&1 1>&2 2>&3)
if [ $? != 0 ]; then ${DVS}dvs; exit 0; fi
#

usrp_port=$(whiptail --title "$T009" --inputbox "$T410" 10 60 ${usrp_port} 3>&1 1>&2 2>&3)
if [ $? != 0 ]; then ${DVS}dvs; exit 0; fi
#


if [ x${usrp_port} = x ]; then

if (whiptail --title "$T009" --yesno "\
      $T413 (Analog_Bridge.ini)

      txPort: 32001, rxPort: 34001

      $T005
" 12 60); then :
else
usrp_port=$(whiptail --title "$T009" --inputbox "$T410" 10 60 ${usrp_port} 3>&1 1>&2 2>&3)
fi
if [ $? != 0 ]; then echo "exit"; exit 0; fi
fi

#------- Create bm.list from DMR_Hotsts.txt ----------------------------------------------

sudo \cp -f ${DATA}bm.list ${DATA}bm.list_old > /dev/null 2>&1

# get the records starting "BM_" from DMR_Hosts.txt and create bm.list_1
sudo grep -i -e "^BM_" ${dir_host}DMR_Hosts.txt | sudo tee ${DATA}bm.list_1 > /dev/null 2>&1

# cut the first column from bm.list_1
sudo cut -f1 ${DATA}bm.list_1 | sudo tee ${DATA}bm.list_2 > /dev/null 2>&1

# add a new line "===Type_in===" in the last line of bm.list
#sudo bash -c 'echo ===Type_in=== >> /var/lib/dvswitch/dvs/bm.list' > /dev/null 2>&1

# number all the lines
sudo nl ${DATA}bm.list_2 | sudo tee ${DATA}bm.list > /dev/null 2>&1

# verify bm.list is valid
file=${DATA}bm.list
if [[ -z `sudo grep "BM_" $file` ]]; then
sudo \cp -f ${DATA}bm.list_old ${DATA}bm.list > /dev/null 2>&1
fi

sudo rm ${DATA}bm.list_* > /dev/null 2>&1

#------- Create bm.list from DMR_Hotsts.txt ----------------------------------------------


value=$(cat ${DATA}bm.list)
num=$(whiptail --title "Local Brandmeister Master Server" --menu "\
\n
      $T163
" 30 42 20 ${value} 3>&1 1>&2 2>&3)
if [ $? != 0 ]; then ${DVS}dvs; exit 0; fi

sel_line=$(sudo awk '$1 == '"$num"' { print $2 }' ${DATA}bm.list)

bm_master=
bm_address=$(awk '$1 == "'${sel_line}'" { print $3 }' ${dir_host}DMR_Hosts.txt)
bm_password=$(awk '$1 == "'${sel_line}'" { print $4 }' ${dir_host}DMR_Hosts.txt)
bm_port=$(awk '$1 == "'${sel_line}'" { print $5 }' ${dir_host}DMR_Hosts.txt)

bm_password=$(whiptail --title "$T009" --inputbox "$T162" 10 60 ${bm_password} 3>&1 1>&2 2>&3)
if [ $? != 0 ]; then ${DVS}dvs; exit 0; fi

#------- AMBE -----------------------------------------------------------------------------

OPTION=$(whiptail --title " $T170 " --menu "\
\n
" 13 80 4 \
"$T171  " "$T172" \
"$T173  " "$T174" \
"$T175  " "$T176" \
"$T177  " "$T178" \
3>&1 1>&2 2>&3)

if [ $? != 0 ]; then ${DVS}dvs; exit 0; fi

case "$OPTION" in
1\ *)ambe_option="1" ;;
2\ *)ambe_option="2" ;;
3\ *)ambe_option="3" ;;
4\ *)ambe_option="4" ;;
esac

if [ $? != 0 ]; then ${DVS}dvs; exit 0; fi
#----------------------------------------------------------------------------------------------------------------------
if [ $ambe_option = "1" ]; then
        ambe_server=$(whiptail --title " IP address of AMBEServer " --inputbox "IP or DDNS address ?" 8 50 ${ambe_server} 3>&1 1>&2 2>&3)
        if [ $? != 0 ]; then ${DVS}dvs; exit 0; fi

        ambe_rxport=$(whiptail --title " Port of AMBEServer " --inputbox "Port (UDP) ?" 8 50 ${ambe_rxport} 3>&1 1>&2 2>&3)
        if [ $? != 0 ]; then ${DVS}dvs; exit 0; fi

elif [ $ambe_option = "2" ]; then
        ambe_baud=$(whiptail --title " Baudrate of ThumbDV or DVstick " --inputbox "Baudrate ? [$T168]" 8 50 ${ambe_baud} 3>&1 1>&2 2>&3)
        if [ $? != 0 ]; then ${DVS}dvs; exit 0; fi

elif [ $ambe_option = "3" ]; then
        ambe_baud=$(whiptail --title " Baudrate of AMBE Board " --inputbox "Baudrate ? [$T168]" 8 50 ${ambe_baud} 3>&1 1>&2 2>&3)
        if [ $? != 0 ]; then ${DVS}dvs; exit 0; fi

elif [ $ambe_option = "4" ]; then :

fi

#----------------------------------------------------------------------------------------------------------------------

if (whiptail --title " $T180 " --yesno "\
$sp09 $T181
$sp09 $T182

$sp09 $T005
" 10 70);
	then
		clear;
		do_config;
	else ${DVS}dvs
fi


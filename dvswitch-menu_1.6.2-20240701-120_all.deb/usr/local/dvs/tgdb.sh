#!/bin/bash

#===================================
SCRIPT_VERSION="Menu Script v.1.60"
SCRIPT_AUTHOR="HL5KY"
SCRIPT_DATE="10/15/2020"
#===================================

source /var/lib/dvswitch/dvs/var.txt


function do_push_msg() {

if (whiptail --title " $T249 " --yesno "\
      $T250

      $T251


      $T005
" 13 70); then :
else ${DVS}tgdb.sh; exit 0
fi
}


function do_collect() {

TERM=ansi whiptail --title "$T029" --infobox "$T006" 8 60

        ${MESSAGE} " Updating Global DB "
        ${DVSWITCH} collectProcessDataFiles > /dev/null 2>&1
        ${MESSAGE} " Adding Favorite DB "
        sudo \cp -f /tmp/*_node_list.txt ${tgdb}

        for mode in DMR DSTAR NXDN P25 YSF; do
                sudo sed -i "1s/.*/Global|||======GLOBAL=======/g" ${tgdb}${mode}_node_list.txt;
        done
}


function do_push() {
        for mode in DMR DSTAR NXDN P25 YSF; do
                do_pushfile ${mode}
        done
}


function do_pushfile() {
        mode=$1
        sudo cat ${tgdb}${mode}_fvrt_list.txt ${tgdb}${mode}_node_list.txt > /tmp/${mode}_node_list.txt;
        sudo ${DVSWITCH} pushfile /tmp/${mode}_node_list.txt;
}


function do_push_end_msg() {

sleep 3
clear

whiptail --msgbox "\

                      $T003

                    $T004

" 10 60 1

${DVS}tgdb.sh; exit 0
}


do_reset_db() {
#whiptail --msgbox "\
if (whiptail --title " $T252 " --yesno "\
$sp05 $T253

$sp05 $T254


$sp05 $T005
" 13 70); then
#" 13 70 1

if [ ${dmr_id:0:3} = 450 ]; then LN="KR"; fi

if [ -d ${tgdb}${LN} ]; then
        sudo \cp -f ${tgdb}${LN}/* ${tgdb}
else
        sudo \cp -f ${tgdb}EN/* ${tgdb}
fi

clear

TERM=ansi whiptail --title "$T029" --infobox "$T006" 8 60

else ${DVS}tgdb.sh; exit 0
fi
}

#================= File Editing =================

sel2=$(whiptail --title " $T239 " --menu "\
\n
$sp09 $T001: Ctrl-X >> Y >> Enter
$sp09 $T002: Ctrl-X >> N
" 19 50 8 \
"1" "$T007 DMR" \
"2" "$T007 DSTAR" \
"3" "$T007 NXDN" \
"4" "$T007 P25" \
"5" "$T007 YSF" \
"6" "$T249" \
"7" "$T252" \
"8" "$T317" \
3>&1 1>&2 2>&3)

if [ $? != 0 ]; then ${DVS}adv_config_menu.sh; exit 0
fi

case $sel2 in
1)
sudo nano ${tgdb}DMR_fvrt_list.txt; ${DVS}tgdb.sh ;;
2)
sudo nano ${tgdb}DSTAR_fvrt_list.txt; ${DVS}tgdb.sh ;;
3)
sudo nano ${tgdb}NXDN_fvrt_list.txt; ${DVS}tgdb.sh ;;
4)
sudo nano ${tgdb}P25_fvrt_list.txt; ${DVS}tgdb.sh ;;
5)
sudo nano ${tgdb}YSF_fvrt_list.txt; ${DVS}tgdb.sh ;;
6)
do_push_msg; do_collect; do_push; do_push_end_msg ;;
7)
do_reset_db; do_push; do_push_end_msg ;;
8)
${DVS}adv_config_menu.sh; exit 0 ;;
esac

clear

exit 0

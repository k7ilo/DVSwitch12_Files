#!/bin/bash

#===================================
SCRIPT_VERSION="Menu Script v.1.60"
SCRIPT_AUTHOR="HL5KY"
SCRIPT_DATE="10/15/2020"
#===================================

source /var/lib/dvswitch/dvs/var.txt

clear


# check if variables in var.txt are vacant then get values from MMDVM_Bridge.ini
if [ "$rx_freq" = "" ] || [ "$rx_freq" = 000000000 ]; then
        file=${MB}MMDVM_Bridge.ini
        tag="RXFrequency TXFrequency Power Latitude Longitude Height Location Description URL"
        var=(rx_freq tx_freq pwr lat lon hgt lctn desc url)

        for para in $tag; do
                val=$(sed -nr "/^\[Info\]/ { :l /^$para[ ]*=/ { s/.*=[ ]*//; p; q;}; n; b l;}" $file)
                var=${var[$n]}
		if [ "$val" != "" ]; then
	                update_var $var "$val"
		else
			update_var $var $val
		fi
                n=$(($n+1))
        done
	source /var/lib/dvswitch/dvs/var.txt
fi


if (whiptail --title " $T009 " --yesno "\
$T215

$T005
" 10 80); then :
        else ${DVS}adv_config_menu.sh; exit 0
fi

rx_MHz=${rx_freq:0:3}"."${rx_freq:3:4}

if [[ $T213 =~ RXFrequency ]]; then T213=$T213; else T213="RXFrequency : $T213"; fi
rx_MHz=$(whiptail --title " $T009 " --inputbox "$T213" 10 60 ${rx_MHz} 3>&1 1>&2 2>&3)
if [ $? != 0 ]; then ${DVS}adv_config_menu.sh; exit 0; fi


if [[ $T216 =~ RXFrequency ]]; then T216=$T216; else T216="RXFrequency : $T216"; fi
until [ ${#rx_MHz} = 8 ]; do
rx_MHz=$(whiptail --title " $T009 " --inputbox "$T216" 10 60 ${rx_MHz} 3>&1 1>&2 2>&3)
if [ $? != 0 ]; then ${DVS}adv_config_menu.sh; exit 0; fi
done

rx_freq=${rx_MHz:0:3}${rx_MHz:4:4}"00"


tx_MHz=${tx_freq:0:3}"."${tx_freq:3:4}

if [[ $T214 =~ TXFrequency ]]; then T214=$T214; else T214="TXFrequency : $T214"; fi
tx_MHz=$(whiptail --title " $T009 " --inputbox "$T214" 10 60 ${tx_MHz} 3>&1 1>&2 2>&3)
if [ $? != 0 ]; then ${DVS}adv_config_menu.sh; exit 0; fi


if [[ $T217 =~ TXFrequency ]]; then T217=$T217; else T217="TXFrequency : $T217"; fi
until [ ${#tx_MHz} = 8 ]; do
tx_MHz=$(whiptail --title " $T009 " --inputbox "$T217" 10 60 ${tx_MHz} 3>&1 1>&2 2>&3)
if [ $? != 0 ]; then ${DVS}adv_config_menu.sh; exit 0; fi
done

tx_freq=${tx_MHz:0:3}${tx_MHz:4:4}"00"

if [[ $T220 =~ Power ]]; then T220=$T220; else T220="Power : $T220"; fi
pwr=$(whiptail --title " $T009 " --inputbox "$T220" 10 60 ${pwr} 3>&1 1>&2 2>&3)
if [ $? != 0 ]; then ${DVS}adv_config_menu.sh; exit 0; fi

if [[ $T218 =~ Latitude ]]; then T218=$T218; else T218="Latitude : $T218"; fi
lat=$(whiptail --title " $T009 " --inputbox "$T218" 10 60 -- ${lat} 3>&1 1>&2 2>&3)
if [ $? != 0 ]; then ${DVS}adv_config_menu.sh; exit 0; fi

if [[ $T219 =~ Longitude ]]; then T219=$T219; else T219="Longitude : $T219"; fi
lon=$(whiptail --title " $T009 " --inputbox "$T219" 10 60 -- ${lon} 3>&1 1>&2 2>&3)
if [ $? != 0 ]; then ${DVS}adv_config_menu.sh; exit 0; fi

if [[ $T221 =~ Height ]]; then T221=$T221; else T221="Height : $T221"; fi
hgt=$(whiptail --title " $T009 " --inputbox "$T221" 10 60 ${hgt} 3>&1 1>&2 2>&3)
if [ $? != 0 ]; then ${DVS}adv_config_menu.sh; exit 0; fi

if [[ $T222 =~ Location ]]; then T222=$T222; else T222="Location : $T222"; fi
lctn=$(whiptail --title " $T009 " --inputbox "$T222" 10 60 "${lctn}" 3>&1 1>&2 2>&3)
if [ $? != 0 ]; then ${DVS}adv_config_menu.sh; exit 0; fi

if [[ $T223 =~ Description ]]; then T223=$T223; else T223="Description : $T223"; fi
desc=$(whiptail --title " $T009 " --inputbox "$T223" 10 60 "${desc}" 3>&1 1>&2 2>&3)
if [ $? != 0 ]; then ${DVS}adv_config_menu.sh; exit 0; fi

url=$(whiptail --title " $T009 " --inputbox "URL" 10 60 ${url} 3>&1 1>&2 2>&3)
if [ $? != 0 ]; then ${DVS}adv_config_menu.sh; exit 0; fi


TERM=ansi whiptail --title "$T029" --infobox "$T006" 8 60


update_var rx_freq ${rx_freq}
update_var tx_freq ${tx_freq}
update_var pwr ${pwr}
update_var lat ${lat}
update_var lon ${lon}
update_var hgt ${hgt}
update_var lctn "${lctn}"
update_var desc "${desc}"
update_var url ${url}


file=${MB}MMDVM_Bridge.ini

function edit_info() {
#if [ "$2" != "" ]; then
#        if [[ "$2" =~ " " ]]; then
#        sudo sed -i -e "/^$1=/ c $1=\"$2\"" ${file}
#        else
        sudo sed -i -e "/^$1=/ c $1=$2" ${file}
#	fi
#fi
}

edit_info RXFrequency ${rx_freq}
edit_info TXFrequency ${tx_freq}
edit_info Power ${pwr}
edit_info Latitude ${lat}
edit_info Longitude ${lon}
edit_info Height ${hgt}
edit_info Location "${lctn}"
edit_info Description "${desc}"
edit_info URL ${url}

sudo systemctl restart mmdvm_bridge

clear

whiptail --msgbox "\

$sp25 $T003

$sp22 $T004

" 11 70 1

${DVS}adv_config_menu.sh; exit 0

#!/usr/bin/env bash
set -o errexit

#===================================
SCRIPT_VERSION="Menu Script v.1.60"
SCRIPT_AUTHOR="HL5KY"
SCRIPT_DATE="10/15/2020"
#===================================

# N4IRS 08/25/2020

#################################################
#                                               #
#  Enable cron task                             #
#                                               #
#################################################

# Start here

while getopts ":yn" opt; do
  case ${opt} in
    y ) echo "Enabling temp-check"
	if [ ! -e /etc/cron.d/chk_temp ]; then
        sudo ln -s /var/lib/dvswitch/dvs/chk_temp /etc/cron.d/chk_temp
	fi
      ;;
    n ) echo "Disabling temp-check"
	if [ -e /etc/cron.d/chk_temp ]; then
        sudo rm  /etc/cron.d/chk_temp
	fi
      ;;
    \? ) echo "Usage: temp-msg.sh [-y] [-n]"
        exit 1
      ;;
  esac
sudo systemctl restart cron
done

exit 0
